package Login;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class AdLogin {
    public static void main(String[] args) throws IOException {

        Scanner scan = new Scanner(System.in);
        System.out.println("Please enter your user name");
        String name = scan.next();
        System.out.println("Please enter your password");
        String pass = scan.next();
        try (BufferedReader br = new BufferedReader(new FileReader("/Users/serra/IntelliJIDEAProjects/BasicJava/src/Login/AdLogin"))) {
            String line;


            while (( line = br.readLine() ) != null) {

                String[] values = line.split(" ");

                String user_name_ = values[0];
                String password_ = values[1];


                if (user_name_.equals(name) &&  (password_).equals(pass)) {

                    System.out.println("You successfully logged in");

                } else if (!user_name_.equals(name) && (password_).equals(pass)) {
                    System.out.println("Your username is wrong try again");

                } else if (user_name_.equals(name) && ! (password_).equals(pass)) {
                    System.out.println("Your password is wrong try again");
                }
            }

        }
    }
}

