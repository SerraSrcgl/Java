package Login;

public class BasicLogin {public static void main(String[]args){
    String name="Serra";
    String password="123";


    if(name.equals("Serra")&&password.equals("123")){
        System.out.printf("You have successfully logged in");

    }else if (name.equals("Serra")&&!password.equals("123")){
        System.out.printf("Wrong password try again");
    }else if (!name.equals("Serra")&&password.equals("123")){
        System.out.printf("Wrong username try again");
    }else{
        System.out.printf("Both are wrong ");
    }
}
}
