package Login;

import java.util.Scanner;

public class Login {
    public static void main(String[] args){

        Scanner scan=new Scanner(System.in);
        System.out.println("Please enter your user name");
        String user_name=scan.next();
        System.out.println("Please enter your password");
        String password=scan.next();



        String user_name_="Serra";
        String password_="123";

        if(user_name.equals(user_name_)&&password.equals(password_)){
            System.out.printf("You have successfully logged in");

        }else if (user_name.equals(user_name_)&&!password.equals(password_)){
            System.out.printf("Wrong password try again");
        }else if (!user_name.equals(user_name_)&&password.equals(password_)){
            System.out.printf("Wrong username try again");
        }else{
            System.out.printf("Both are wrong ");
        }

    }
}
