package Register;

import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

public class AdRegister {
    public static void main(String[] args) throws IOException, NoSuchAlgorithmException {
        Scanner scan=new Scanner(System.in);
        System.out.println("Please enter your name");
        String name=scan.next();
        System.out.println("Please enter your surname");
        String surname=scan.next();
        System.out.println("Please enter your password");
        String password=scan.next();
        System.out.println("Please enter your gender as char (F/M)");
        String gender=scan.next();



        FileWriter fw=new FileWriter("/Users/serra/IntelliJIDEAProjects/BasicJava/src/Register/Register");
        fw.write(name+"/"+surname+"/"+md5(password)+"/"+gender);
        fw.close();
    }


    public static String md5(String input) {

        String md5 = null;
        if (null == input) return null;

        try {

            //Create MessageDigest object for MD5
            MessageDigest digest = MessageDigest.getInstance("MD5");

            //Update input string in message digest
            digest.update(input.getBytes(), 0, input.length());

            //Converts message digest value in base 16 (hex)
            md5 = new BigInteger(1, digest.digest()).toString(16);

        } catch (NoSuchAlgorithmException e) {

            e.printStackTrace();

        }
        return md5;
    }


   
}

