package Register;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Register {
    public static void main(String[] args) throws IOException {
        Scanner scanner=new Scanner(System.in);
        System.out.println("Please enter your name");
        String name= scanner.next();
        System.out.println("Please enter your surname");
        String surname=scanner.next();
        System.out.println("Please enter password for yourself");
        String password=scanner.next();
        System.out.println("Enter your gender as char (F/M)");
        String gender=scanner.next();

        FileWriter fw=new FileWriter("/Users/serra/IntelliJIDEAProjects/BasicJava/src/Register/Register");
        fw.write(name+"/"+surname+"/"+password+"/"+gender);
fw.close();
        System.out.println("*******************");
        System.out.println("You have successfully registered");
        System.out.println("********************");
    }
}
